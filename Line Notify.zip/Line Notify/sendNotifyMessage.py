import requests
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def assembleMessage(access_token,message):
	access_token = access_token
	url = 'https://notify-api.line.me/api/notify'

	headers = {
		'Content-Type':'application/x-www-form-urlencoded',
		'Authorization':'Bearer '+ access_token
	}

	data = {'message':message}

	r = requests.post(url, headers=headers, params=data)

	return r.status_code

def sendMessage():
	scope=['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
	creds = ServiceAccountCredentials.from_json_keyfile_name('<你的GCP金鑰JSON檔>',scope)
	client = gspread.authorize(creds)
	spreadSheet = client.open('<妳的雲端試算表檔名>')
	workSheet_notify = spreadSheet.worksheet('<你的工作表檔名>')
	userTokenlists = workSheet_notify.get_all_values()
	for access_token in userTokenlists:
		print(assembleMessage(access_token[0],'星期四教育部官員來訪，放假一天，YEAH'))


sendMessage()