import flask
import requests
import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope=['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('<你的GCP金鑰JSON檔>',scope)
client = gspread.authorize(creds)
spreadSheet = client.open('<妳的雲端試算表檔名>')
workSheet_notify = spreadSheet.worksheet('<你的工作表檔名>')

app = flask.Flask(__name__)
app.config['DEBUG'] = True

@app.route('/register', methods=['GET'])
def register():
	return '註冊完成'

@app.route('/linenotify', methods=['GET'])
def linenotify():
	if 'code' in flask.request.args:
		code = flask.request.args['code']
		url = 'https://notify-bot.line.me/oauth/token?'
		url += 'grant_type=authorization_code&'
		url += 'code='+code+'&'
		url += 'redirect_uri=<你的webhook網址>&'
		url += 'client_id=<你的client_id>&'
		url += 'client_secret=<你的client_secret>'
		
		r = requests.post(url).json()

		access_token = r['access_token']
		workSheet_notify.append_row([access_token])

		return '連線成功'

	else:
		return False

if __name__ == "__main__":
    import os
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=True)


#註冊網站：https://notify-bot.line.me/oauth/authorize?response_type=code&client_id=VhUMIP1Csyuxz0QOBuUlyM&redirect_uri=https://hp2020demo-linenotify.herokuapp.com/linenotify&scope=notify&state=NO_STATE